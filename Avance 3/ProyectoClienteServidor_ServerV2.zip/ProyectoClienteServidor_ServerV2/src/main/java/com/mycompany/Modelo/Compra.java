package com.mycompany.Modelo;

import java.time.LocalDateTime;

public class Compra {

    private Cliente cliente;
    private Articulo articulo;
    private String fechaHoraActual;

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public String getFechaHoraActual() {
        return fechaHoraActual;
    }

    public void setFechaHoraActual(String fechaHoraActual) {
        this.fechaHoraActual = fechaHoraActual;
    }

    @Override
    public String toString() {
        return "Compras{" + "cliente=" + cliente + ", articulo=" + articulo + ", fechaHoraActual=" + fechaHoraActual + '}';
    }

    public Compra(Cliente cliente, Articulo articulo, String fechaHoraActual) {
        this.cliente = cliente;
        this.articulo = articulo;
        this.fechaHoraActual = fechaHoraActual;
    }

    public Compra() {
    }

}
