package com.mycompany.Controlador;

import com.google.gson.Gson;
import com.mycompany.Conexion.ConexionMysql;
import com.mycompany.Conexion.SQLArticulo;
import com.mycompany.Modelo.Articulo;
import com.mycompany.Modelo.Cliente;
import com.mycompany.Modelo.Compra;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.sql.Timestamp;
import javax.swing.JOptionPane;

public class LogicaArticuloControlador {

    private static final Logger LOGGER = Logger.getLogger(LogicaArticuloControlador.class.getName());

    ConexionMysql con = new ConexionMysql(); 
    Connection cn = con.getConection();
    private Connection connection;

    public LogicaArticuloControlador(Connection cn) {
        this.cn = cn;
    }

    public LogicaArticuloControlador() {
    }

    public boolean registrarArticulo(String json) {
        Gson gson = new Gson();
        Articulo p = gson.fromJson(json, Articulo.class);

        String sql = "INSERT INTO articulos(nombre, cantidad, precio, tipo) VALUES(?,?,?,?)";
        PreparedStatement ps = null;

        try {
            if (cn != null) {
                ps = cn.prepareStatement(sql);
                ps.setString(1, p.getNombre());
                ps.setInt(2, p.getCantidad());
                ps.setDouble(3, p.getPrecio());
                ps.setString(4, p.getTipo());
                ps.executeUpdate();
                return true;
            } else {
                return false;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (cn != null) {
                    cn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean procesarCompra(String json) {
        List<Articulo> listaArticulosEnElServidor = obtenerArticulosLista();
        List<Articulo> listaArticulosEnElCarrito = new LinkedList<>();
        Gson gson = new Gson();
        Articulo[] articulos = gson.fromJson(json, Articulo[].class);
        for (Articulo articulo : articulos) {
            listaArticulosEnElCarrito.add(articulo);
        }
        if (!validarCompraCarritoDeCompras(listaArticulosEnElServidor, listaArticulosEnElCarrito)) {
            return false;
        }
        return actualizarInventario(listaArticulosEnElCarrito);
    }

    private void agregarCompraAlHistorial(Cliente clienteQueCompro, Articulo articulo, int cantidad) {
        String sql = "INSERT INTO registrodecompras(idDelArticulo, CantidadDeArticulo, idDelCliente, precioTotal, horaDeLaCompra) VALUES(?,?,?,?,?)";
        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, articulo.getId());
            ps.setInt(2, cantidad);
            ps.setInt(3, clienteQueCompro.getId());
            ps.setDouble(4, articulo.getPrecio() * cantidad);
            ps.setTimestamp(5, new java.sql.Timestamp(System.currentTimeMillis())); // Agregar la hora actual
            ps.executeUpdate(); // Ejecuta la consulta
            System.out.println("Compra registrada en historial: " + articulo.getNombre());
        } catch (SQLException ex) {
            Logger.getLogger(LogicaArticuloControlador.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error al insertar en registrodecompras: " + ex.getMessage());
        }
    }

    private boolean actualizarInventario(List<Articulo> articulos) {
        String sql = "UPDATE articulos SET cantidad = cantidad - ? WHERE id = ?";
        try (Connection connection = con.getConection(); PreparedStatement ps = connection.prepareStatement(sql)) {

            connection.setAutoCommit(false); // Inicia la transacción
            Cliente Brandon = new Cliente();
            Brandon.setId(1);
            for (Articulo articulo : articulos) {
                agregarCompraAlHistorial(Brandon, articulo, articulo.getCantidad());
                ps.setInt(1, articulo.getCantidad());
                ps.setInt(2, articulo.getId());
                ps.addBatch();
            }

            ps.executeBatch();
            connection.commit(); // Confirma la transacción
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            try (Connection connection = con.getConection()) {
                if (connection != null) {
                    connection.rollback(); // Revierte en caso de error
                }
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
            return false;
        }
    }

    private boolean validarCompraCarritoDeCompras(List<Articulo> listaArticulosEnElServidor, List<Articulo> listaArticulosEnElCarrito) {
        for (Articulo articuloEnCarrito : listaArticulosEnElCarrito) {
            boolean encontrado = false;
            for (Articulo articuloEnServidor : listaArticulosEnElServidor) {
                if (articuloEnServidor.getId() == articuloEnCarrito.getId()) {
                    if (articuloEnServidor.getCantidad() < articuloEnCarrito.getCantidad()) {
                        LOGGER.log(Level.WARNING, "No hay suficiente inventario para el artículo con ID: " + articuloEnCarrito.getId());
                        return false;
                    }
                    encontrado = true;
                    break;
                }
            }
            if (!encontrado) {
                LOGGER.log(Level.WARNING, "Artículo no encontrado en el inventario con ID: " + articuloEnCarrito.getId());
                return false;
            }
        }
        return true;
    }

    public List<Compra> obtenerListadoDeCompras() {
        List<Compra> listaDeCompras = new ArrayList<>();
        String sql = "SELECT idDelArticulo, CantidadDeArticulo, idDelCliente, precioTotal, horaDeLaCompra FROM registrodecompras";
        PreparedStatement ps = null;
        ResultSet rs = null;

        if (cn != null) {
            try {
                ps = cn.prepareStatement(sql);
                rs = ps.executeQuery();

                while (rs.next()) {
                    Compra compra = new Compra();
                    Articulo articulo = new Articulo();
                    Cliente cliente = new Cliente();

                    // Rellenar los datos del artículo y del cliente
                    articulo.setId(rs.getInt("idDelArticulo"));
                    articulo.setCantidad(rs.getInt("CantidadDeArticulo"));
                    articulo.setPrecio(rs.getDouble("precioTotal"));
                    cliente.setId(rs.getInt("idDelCliente"));

                    // Asociar artículo y cliente con la compra
                    compra.setArticulo(articulo);
                    compra.setCliente(cliente);

                    // Obtener y establecer la fecha y hora de la compra
                    Timestamp timestamp = rs.getTimestamp("horaDeLaCompra");
                    if (timestamp != null) {
                        LocalDateTime fechaHoraCompra = timestamp.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
                        compra.setFechaHoraActual(fechaHoraCompra.toString());
                    }

                    // Añadir la compra a la lista
                    listaDeCompras.add(compra);
                }
            } catch (SQLException ex) {
                Logger.getLogger(LogicaArticuloControlador.class.getName()).log(Level.SEVERE, "Error al obtener datos de la base de datos: " + ex.getMessage(), ex);
            } finally {
                try {
                    if (rs != null) {
                        rs.close();
                    }
                    if (ps != null) {
                        ps.close();
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(LogicaArticuloControlador.class.getName()).log(Level.SEVERE, "Error al cerrar recursos: " + ex.getMessage(), ex);
                }
            }
        }
        JOptionPane.showMessageDialog(null, listaDeCompras);
        return listaDeCompras;
    }

    public String jasonCompras() {
        Gson gson = new Gson();
        String json = gson.toJson(obtenerListadoDeCompras());
        return json;
    }

    private List<Articulo> obtenerArticulosLista() {
        List<Articulo> listaArticulos = new ArrayList<>();
        String sql = "SELECT id, tipo, nombre, cantidad, precio FROM articulos";// se crea una sentencia 

        PreparedStatement ps = null;

        if (cn != null) {
            try {
                ps = cn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();

                while (rs.next()) {
                    Articulo articulo = new Articulo();
                    articulo.setId(rs.getInt("id"));
                    articulo.setTipo(rs.getString("tipo"));
                    articulo.setNombre(rs.getString("nombre"));
                    articulo.setCantidad(rs.getInt("cantidad"));
                    articulo.setPrecio(rs.getDouble("precio"));
                    listaArticulos.add(articulo);
                }
            } catch (SQLException ex) {
                Logger.getLogger(SQLArticulo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return listaArticulos;
    }

    public String jsonArticulos() {
        Gson gson = new Gson();
        String json = gson.toJson(obtenerArticulosLista());
        return json;
    }

    public boolean actualizarArticulo(String articulorecibido) {
        String sql = "UPDATE articulos SET tipo = ?, nombre = ?, cantidad = ?, precio = ? WHERE id = ?";

        if (cn == null) {
            System.out.println("No se pudo establecer la conexión a la base de datos.");
            return false;
        }
        Gson json = new Gson();
        Articulo articulo = json.fromJson(articulorecibido, Articulo.class);

        try (PreparedStatement pst = cn.prepareStatement(sql)) {
            pst.setString(1, articulo.getTipo());
            pst.setString(2, articulo.getNombre());
            pst.setInt(3, articulo.getCantidad());
            pst.setDouble(4, articulo.getPrecio());
            pst.setInt(5, articulo.getId());

            int rowsAffected = pst.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Error al actualizar el artículo: " + e.getMessage());
            return false;
        }
    }

    private List<Articulo> obtenerArticulosTipo(String tipo) {//este metodo se crea para obtener los articulos por el tipo de articulo
        List<Articulo> listaArticulos = new ArrayList<>();
        String sql = "SELECT id, tipo, nombre, cantidad, precio FROM articulos WHERE tipo = ?"; // acaa se busca por medio del tipo y lo que se hace es que para la funcino es necseario un String el cual se declara en el llamado de la funcino en la vista
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            if (cn != null) {
                ps = cn.prepareStatement(sql);
                ps.setString(1, tipo); //aca se setea el parametroa  utilizar
                rs = ps.executeQuery();
            }
            while (rs.next()) {
                Articulo articulo = new Articulo();
                articulo.setId(rs.getInt("id"));
                articulo.setTipo(rs.getString("tipo"));
                articulo.setNombre(rs.getString("nombre"));
                articulo.setCantidad(rs.getInt("cantidad"));
                articulo.setPrecio(rs.getDouble("precio"));
                listaArticulos.add(articulo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SQLArticulo.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listaArticulos;
    }

    public String jsonArticulosTipo(String tipo) {
        Gson gson = new Gson();
        String json = gson.toJson(obtenerArticulosTipo(tipo));
        return json;
    }

}
