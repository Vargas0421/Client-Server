package com.mycompany.Conexion;

import com.mycompany.Modelo.Cliente;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConexionServidor {

    private ServerSocket server;
    private List<GestionCliente> gestiones = new ArrayList<>();

    public ConexionServidor() {
        try {
            server = new ServerSocket(6060);
            System.out.println("Servidor iniciado en el puerto 6060.");
        } catch (IOException ex) {
            Logger.getLogger(ConexionServidor.class.getName()).log(Level.SEVERE, "Error al iniciar el servidor", ex);
        }
    }
    
    public synchronized void ingresarGestion(GestionCliente e){
        gestiones.add(e);
    }

    public void iniciarSesion() {
        while (true) {
            try {
                Socket socket = this.server.accept();
                GestionCliente gestion = new GestionCliente(socket);
                gestion.start();
                ingresarGestion(gestion);
                System.out.println("Cliente conectado desde: " + socket.getInetAddress());
            } catch (IOException ex) {
                Logger.getLogger(ConexionServidor.class.getName()).log(Level.SEVERE, "Error al aceptar la conexión", ex);
            }
        }
    }

}
