package com.mycompany.proyectoclienteservidor.vista;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mycompany.proyectoclienteservidor.Conexion.ConecxionCliente;
import com.mycompany.proyectoclienteservidor.Modelo.Articulo;
import com.mycompany.proyectoclienteservidor.Modelo.Compra;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.JOptionPane;

public class visualizacionDelListadoDeCompras extends javax.swing.JFrame {

    private List<Compra> listaDeCompras = new ArrayList<>();
    private Map<String, List<Compra>> comprasPorFecha = new HashMap<>();

    public visualizacionDelListadoDeCompras() {
        initComponents();
        cargarDatos();
    }

    private void cargarDatos() {// aca se cargan los datos
        ConecxionCliente conexion = new ConecxionCliente();
        String respuesta = conexion.iniciarConexion(pedirInformacion());
        listaDeCompras = cargarCompras(respuesta);
        agruparComprasPorFecha(listaDeCompras);
        List<String> fechas = obtenerFechas(listaDeCompras);
        JcomboBocSeleccionarFecha.removeAllItems();
        for (String fecha : fechas) {
            JcomboBocSeleccionarFecha.addItem(fecha);
        }
    }

    public String pedirInformacion() {// aca se le pide la informacion medinate un objeto con el metodo 10
        Articulo a = new Articulo();
        a.setIdDeMetodo(10);
        Gson gson = new Gson();
        String json = gson.toJson(a);
        return json;
    }

    private List<String> obtenerFechas(List<Compra> lista) {
        Set<String> fechasSet = new HashSet<>(); // se utiliza  un Set para eliminar duplicados
        for (Compra compra : lista) {
            fechasSet.add(compra.getFechaHoraActual());
        }
        return new ArrayList<>(fechasSet); // se convierte el Set a una lista
    }

    private void agruparComprasPorFecha(List<Compra> listaDeCompras) { // aca se agrupan las compra por la fecha y de esta maenra se pueden mostrara las compras realizadas por la misma persona
        comprasPorFecha.clear(); // Limpia el mapa antes de llenarlo

        for (Compra compra : listaDeCompras) {
            String fecha = compra.getFechaHoraActual();
            if (!comprasPorFecha.containsKey(fecha)) {
                comprasPorFecha.put(fecha, new ArrayList<>());
            }
            comprasPorFecha.get(fecha).add(compra);
        }
    }

    private void mostrarCompras(List<Compra> compras) { // metodo para mostrar las comras
        jTextArea1.setText("");// se carga el area en blanco para en caso de que no hayan compras no mostrar nada
        if (compras == null || compras.isEmpty()) {// si no hay compraas
            jTextArea1.append("No hay compras para la fecha seleccionada.\n");
            return;
        }// de haber compras se realiza una logica para obtener la informacino de las mimas y mostrarlas en pantalla 
        int numeroCompra = 1;
        jTextArea1.append("Compras\n");
        for (Compra compra : compras) {
            jTextArea1.append(numeroCompra + ". Compra " + numeroCompra + ":\n");
            jTextArea1.append("El cliete con el id: " + compra.getCliente().getId() + " ha comprado lo siguiente" + "\n"); // Asumiendo que Cliente.toString() devuelve el nombre del usuario
            break;
        }
        double totalCompra = 0;

        for (Compra compra : compras) {
            Articulo articulo = compra.getArticulo();
            jTextArea1.append(" articulo con el id: " + articulo.getId() + ", con una cantidad de: " + articulo.getCantidad() + ",  para un precio de individual de : " + articulo.getPrecio() + "\n");
            totalCompra += articulo.getCantidad() * articulo.getPrecio();
        }
        jTextArea1.append("Total de la compra: " + totalCompra + "\n");
    }

    public List<Compra> cargarCompras(String json) {// medinate este metodo se cargan las compras enviadas por el servidor y se devuelve en un array
        if (json == null || json.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "No se recibieron datos de compras.");
            return new ArrayList<>();
        }
        Gson gson = new GsonBuilder().registerTypeAdapter(LocalDateTime.class, new LocalDateTimeAdapter()).create();
        try {
            Compra[] listaDeComprasArray = gson.fromJson(json, Compra[].class);
            return new ArrayList<>(Arrays.asList(listaDeComprasArray));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al deserializar los datos de compras: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        JcomboBocSeleccionarFecha = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Atras");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        JcomboBocSeleccionarFecha.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        JcomboBocSeleccionarFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JcomboBocSeleccionarFechaActionPerformed(evt);
            }
        });

        jLabel1.setText("Seleccionar fecha");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jTextArea1.setText("Aca se muestran las compras \n");
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(JcomboBocSeleccionarFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 9, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 976, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(JcomboBocSeleccionarFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(51, 51, 51))
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 614, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Adminitrar a = new Adminitrar();
        a.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void JcomboBocSeleccionarFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JcomboBocSeleccionarFechaActionPerformed
         String fechaSeleccionada = (String) JcomboBocSeleccionarFecha.getSelectedItem();
        if (fechaSeleccionada != null) {
            List<Compra> comprasEnFecha = comprasPorFecha.get(fechaSeleccionada);
            mostrarCompras(comprasEnFecha);
        }    }//GEN-LAST:event_JcomboBocSeleccionarFechaActionPerformed

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(visualizacionDelListadoDeCompras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(visualizacionDelListadoDeCompras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(visualizacionDelListadoDeCompras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(visualizacionDelListadoDeCompras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new visualizacionDelListadoDeCompras().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> JcomboBocSeleccionarFecha;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
